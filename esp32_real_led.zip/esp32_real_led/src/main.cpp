#include <Arduino.h>

int lampu=26;
int lampu2=33;
int lampu3=27;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");
  pinMode( lampu, OUTPUT);
  pinMode( lampu2, OUTPUT);
  pinMode( lampu3, OUTPUT);
}

void loop() {
  // lampu merah nyala
  digitalWrite(lampu, HIGH);
  delay(3000); // delay lampu nyala

  digitalWrite(lampu, LOW);
  delay(2000); // delay lampu mati

  //lampu2 kuning nyala
  digitalWrite(lampu2, HIGH);
  delay(2000); //delay lampu nyala
  digitalWrite(lampu2, LOW);
  delay(1000);

  //lampu3 ijo nyala
  digitalWrite(lampu3, HIGH);
  delay(6000); //delay lampu nyala
  digitalWrite(lampu3, LOW);
  delay(1000);
 } 